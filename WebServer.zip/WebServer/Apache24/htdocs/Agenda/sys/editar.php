<?php

    session_start();


    
    include_once("classes/Connect.php");
    $obj = new conect();
    $resultado = $obj->ConectarBanco();

    

$sql = "SELECT * FROM contatos WHERE id_contatos = ".$_GET['id_contato'].";";


    $executado = $resultado->prepare($sql);
    $indice = 0;


    if ($executado->execute()) {
        while ($linha = $executado->fetch(PDO::FETCH_ASSOC)) {
            $linhas[$indice] = $linha;
            $indice++;
        }
    }



?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Cadastro</title>
    <link rel="stylesheet" href="adiciona.css">
    <link rel="icon" type="image" href="css/img/rt.png">

</head>

<body>

    <form action="editar.php?id_contato=<?= $_GET['id_contato']; ?>" method="post">


        <h1 class="titu">Editar Contatos</h1>

        <div class="central">


            <table>
                <tr>
                    <td coslpan="2">&nbsp;</td>
                </tr>

                <tr>
                    <td style="text-align: center;" colspan="2">
                        <img src="img/edita.png" alt="" width="20%">
                    </td>
                </tr>

                <tr>
                    <td><label for="">Nome: </label></td>
                    <td><input required placeholder="Nome" name="nome" type="text" value="<?= $linhas[0]['nome']; ?>"></td>
                </tr>

                <tr>
                    <td><label for="">Endereço: </label></td>
                    <td><input required placeholder="Endereço" name="endereco" type="text" value="<?= $linhas[0]['endereco']; ?>"></td>
                </tr>

                <tr>
                    <td><label for="">Telefone: </label></td>
                    <td><input required placeholder="Telefone" name="telefone" type="number" value="<?= $linhas[0]['telefone']; ?>"></td>
                </tr>

                <tr>
                    <td><label for="">Email: </label></td>
                    <td><input required placeholder="Email" name="email" type="text" value="<?= $linhas[0]['email']; ?>"></td>
                </tr>


                <tr>
                    <td style="text-align: center;" colspan="2">
                        <button class="c" name="Confirmar" type="submit">Confirmar</button>
                    </td>
                </tr>


                <tr>
                    <td style="text-align: center;" colspan="2">
                        <a href="pesquisa.php"><button class="c" name="Voltar" type="button">Voltar</button></a>
                    </td>
                </tr>
            </table>
    </form>

    </div>


</body>

</html>


<?php
extract($_POST);
if (isset($_POST["Confirmar"])) {

    include_once("classes/Connect.php");
    $obj = new conect();
    $resultado = $obj->ConectarBanco();

    $nome = $_POST['nome'];
    $endereco = $_POST['endereco'];
    $telefone = $_POST['telefone'];
    $email = $_POST['email'];

    $sql = "UPDATE contatos SET nome = '".$nome."', endereco = '".$endereco."', telefone = '".$endereco."', email = '".$email."' WHERE id_contatos = ".$_GET['id_contato'].";";


    $executado = $resultado->prepare($sql);


    if ($executado->execute()) {
        echo '
                <script>
                    alert("Contato Atualizado!!");
                </script>
            ';
    } else {
        echo "Algo deu errado!";
    }
}


?>