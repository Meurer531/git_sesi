<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Pesquisa Contato</title>
    <link rel="stylesheet" href="pesqui.css">
    <link rel="icon" type="image" href="img/rt.png">
</head>
<body>

    <form method="post" action="pesquisa.php">
        <h1 class="titi">Editar Contato</h1>

        <div class="centro">

            <div class="item">
                <a href=""><img src="img/sd.png" class="sd" width="70px" alt=""></a>
                <p class="pp">Adicionar Contato</p>
            </div>

            <div class="item">
                <a href=""><img src="img/lixeira.png" width="70px" class="lixei" alt=""></a>
                <p class="pp">Excluir Contato</p>
            </div>

            <div class="item">
                <a href=""><img src="img/pesquisa.png" width="70px" class="sd" alt=""></a>
                <p class="pp">Pesquisar</p>
            </div>
            <div class="item">
                <a href=""><img src="img/edita.png" width="70px" class="sd" alt=""></a>
                <p class="pp">Editar</p>
            </div>

        </div>
    </form>
</body>
</html>
<?php
    extract($_POST);
    if (isset($_POST["Confirmar"])) {
    
        include_once("sys/classes/Connect.php");
        $obj = new conect();
        $resultado = $obj->ConectarBanco();
        
        $sql = "select * from contatos";
    }

    $executado = $resultado->prepare($sql);
    $indice = 0;
    

    if($executado->execute())
        {
            while($linha = $executado->fetch(PDO::FETCH_ASSOC))
            {
                $linhas[$indice] = $linha;
                $indice++;
            }

            $i = 0;
           
            echo '
            <table class="tabela">
                    <tr>
                        <td>Foto</td>
                        <td>Nome</td>
                        <td>Endereco</td>
                        <td>Telefone</td>
                        <td>Email</td>
                        <td>Celular</td>
                        <td>Atualizar</td>
                        <td>Deletar</td>
                    </tr>';
            while($i < $indice)
            {
                if($i%2 != 0)
                {
                    $cor = "#FFFFFF;";
                }else{
                    $cor = "#CCCCCC;";
                }
            echo '
                
                    <tr style="background-color:'.$cor.'">
                        <td><img width="35px" src="'.$linhas[$i]['imagem'].'" /></td>
                        <td>'.$linhas[$i]['nome'].'</td>
                        <td>'.$linhas[$i]['endereco'].'</td>
                        <td>'.$linhas[$i]['telefone'].'</td>
                        <td>'.$linhas[$i]['email'].'</td>
                        <td>'.$linhas[$i]['celular'].'</td>  
                        <td><a href="update.php?var='.base64_encode($linhas[$i]["id_agenda"]).'"><button id="botaoUpdate" name="atualizar" type="submit">Atualizar Campos</button></a></td> 
                        <td><a href="delete.php?var='.$linhas[$i]["id_agenda"].'"><button id="botaoDelete" name="deletar" type="submit">Deletar Campos</button></a></td>
                    </tr>
            ';
            $i++;
            }
            echo '</table>';
        }
        else
        {
            echo "Deu errado cara!!";
        }
    



?>