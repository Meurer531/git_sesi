<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Pesquisa Contato</title>
    <link rel="stylesheet" href="pesqui.css">
</head>

<body>


    <form method="post" action="pesquisa.php">
        <h1 class="titi">Editar Contato</h1>

        <div class="centro">

            <div>
                <a href=""><img src="img/sd.png" class="sd" width="70px" alt=""></a>
                <p style="color: #fff; margin-left: 530px; margin-top: -10px;">Adicionar Contato</p>
            </div>

            <div>
                <a href=""><img src="img/lixeira.png" class="lixei" width="70px" alt=""></a>
                <p style="color: #fff; margin-left: 695px;">Excluir Contato</p>
            </div>

            


        </div>
    </form>
</body>

</html>