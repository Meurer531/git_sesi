<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Pesquisa Contato</title>
    <link rel="stylesheet" href="pesqui.css">
    <link rel="icon" type="image" href="img/rt.png">
</head>

<script>
    // Função que será chamada quando o usuário clicar no link de excluir
    function confirmDelete() {
        return confirm("Você tem certeza que deseja excluir este contato?");
    }
</script>


<body>

    <form method="post" action="pesquisa.php">
        <h1 class="titi">Editar Contato</h1>

        <div class="centro">

            <div class="item">
                <img src="img/sd.png" class="sd" width="70px" alt="">
                <button><a href="adicionar.php" name="adicionar" type="submit">
                        <p>Adicionar Contato</p>
                    </a></button>
            </div>

            <div class="item">
                <img src="img/lixeira.png" width="70px" class="lixei" alt="">
                <button><a href="excluir.php" name="excluir" type="submit">
                        <p>Excluir Contato</p>
                    </a></button>
            </div>

            <div class="item">
                <img src="img/pesquisa.png" width="70px" class="sd" alt="">
                <button><a href="" name="pesquisar" type="submit">
                        <p>Pesquisar</p>
                    </a></button>
            </div>
            <div class="item">
                <img src="img/edita.png" width="70px" class="sd" alt="">
                <button><a href="editar.php" name="editar" type="submit">
                        <p>Editar Contato</p>
                    </a></button>
            </div>
            <div class="item">
                <img src="img/listar.png" width="70px" class="sd" alt="">
                <a href=""><button name="lista" type="submit">
                        <p>Listar Contatos</p>
                    </button></a>
            </div>

        </div>
    </form>
</body>

</html>
<?php
extract($_POST);
if (isset($_POST["lista"])) {

    include_once("classes/Connect.php");
    $obj = new conect();
    $resultado = $obj->ConectarBanco();

    $sql = "SELECT * FROM contatos";


    $executado = $resultado->prepare($sql);
    $indice = 0;


    if ($executado->execute()) {
        while ($linha = $executado->fetch(PDO::FETCH_ASSOC)) {
            $linhas[$indice] = $linha;
            $indice++;
        }

        $i = 0;

        echo '
            <table style="text-align: center;" class="tabela">
                    <tr>
                        <td>Nome</td>
                        <td>Endereco</td>
                        <td>Email</td>
                        <td>Telefone</td>
                    </tr>';
        while ($i < $indice) {
            if ($i % 2 != 0) {
                $cor = "#df6767";
            } else {
                $cor = "#ee7834;";
            }
            echo '
                
                    <tr style="text-align: center; background-color:' . $cor . '">
                        <td>' . $linhas[$i]['nome'] . '</td>
                        <td>' . $linhas[$i]['endereco'] . '</td>
                        <td>' . $linhas[$i]['email'] . '</td>
                        <td>' . $linhas[$i]['telefone'] . '</td>
                        <td>
                            
                            <a href="pesquisa.php?id_contato=' . $linhas[$i]['id_contatos'] . '" onclick="return confirmDelete()">Excluir</a>
                        </td>
                    </tr>
            ';
            $i++;
        }
        echo '</table>';
    } else {
        echo "Deu errado cara!!";
    }
}


if (isset($_GET['id_contato'])) {
    $id_contato = $_GET['id_contato'];

    include_once("classes/Connect.php");
    $obj = new conect();
    $resultado = $obj->ConectarBanco();

    $sql = "DELETE FROM contatos WHERE id_contatos = :id_contato";
    $executado = $resultado->prepare($sql);

    $executado->bindParam(':id_contato', $id_contato, PDO::PARAM_INT);

    if ($executado->execute()) {

        header("Location: pesquisa.php?msg=Contato excluído com sucesso");
        exit;
    } else {
        echo "Erro ao excluir o contato.";
    }
}

if (isset($_GET['msg'])) {
    echo "<p>" . $_GET['msg'] . "</p>";
}


?>