<?php

    session_start();

?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Cadastro</title>
    <link rel="stylesheet" href="adiciona.css">
    <link rel="icon" type="image" href="css/img/rt.png">

</head>

<body>

    <form action="adicionar.php" method="post">


        <h1 class="titu">Adicionar Contatos</h1>

        <div class="central">


            <table>
                <tr>
                    <td coslpan="2">&nbsp;</td>
                </tr>

                <tr>
                    <td style="text-align: center;" colspan="2">
                        <img src="img/cont.png" alt="" width="20%">
                    </td>
                </tr>

                <tr>
                    <td><label for="">Nome: </label></td>
                    <td><input required placeholder="Nome" name="nome" type="text"></td>
                </tr>

                <tr>
                    <td><label for="">Endereço: </label></td>
                    <td><input required placeholder="Endereço" name="endereco" type="text"></td>
                </tr>

                <tr>
                    <td><label for="">Telefone: </label></td>
                    <td><input required placeholder="Telefone" name="telefone" type="number"></td>
                </tr>

                <tr>
                    <td><label for="">Email: </label></td>
                    <td><input required placeholder="Email" name="email" type="text"></td>
                </tr>


                <tr>
                    <td style="text-align: center;" colspan="2">
                        <button class="c" name="Confirmar" type="submit">Confirmar</button>
                    </td>
                </tr>


                <tr>
                    <td style="text-align: center;" colspan="2">
                        <a href="pesquisa.php"><button class="c" name="Voltar" type="button">Voltar</button></a>
                    </td>
                </tr>
            </table>
    </form>

    </div>


</body>

</html>


<?php
extract($_POST);
if (isset($_POST["Confirmar"])) {

    include_once("classes/Connect.php");
    $obj = new conect();
    $resultado = $obj->ConectarBanco();

    $sql = "INSERT INTO contatos (nome, endereco, telefone, email, usuario_idfk) VALUES ('" . $_POST['nome'] . "', '" . $_POST['endereco'] . "', '" . $_POST['telefone'] . "', '" . $_POST['email'] . "', ". $_SESSION['id'].");";


    $executado = $resultado->prepare($sql);


    if ($executado->execute()) {
        echo '
                <script>
                    alert("Contato adicionado");
                </script>
            ';
    } else {
        echo "Algo deu errado!";
    }
}


?>