
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Cadastro</title>
    <link rel="stylesheet" href="adiciona.css">
    <link rel="icon" type="image" href="css/img/rt.png">

    <script>
        function msgAlerta(event) {
            var input = document.querySelectorAll('input[required]');
            var allFilled = true;

            // Verificando se todos os campos obrigatórios estão preenchidos
            input.forEach(function(input) {
                if (input.value.trim() === "") {
                    allFilled = false;
                }
            });

            if (!allFilled) {
                // Se não estiverem todos preenchidos, exibe a mensagem e previne o envio do formulário
                alert("Por Favor, preencha todos os campos.");
                event.preventDefault(); // Impede o envio do formulário
            } else {
                // Se todos estiverem preenchidos, exibe a mensagem de sucesso
                alert("Novo contato adicionado com sucesso.");
            }
        }
    </script>

</head>

<body>

    <form action="adicionar.php" method="post">


        <h1 class="titu">Adicionar Contatos</h1>

        <div class="central">


            <table>
                <tr>
                    <td coslpan="2">&nbsp;</td>
                </tr>

                <tr>
                    <td style="text-align: center;" colspan="2">
                        <img src="img/cont.png" alt="" width="20%">
                    </td>
                </tr>

                <tr>
                    <td><label for="">Nome: </label></td>
                    <td><input required placeholder="Nome" type="text"></td>
                </tr>

                <tr>
                    <td><label for="">Endereço: </label></td>
                    <td><input required placeholder="Endereço" type="text"></td>
                </tr>

                <tr>
                    <td><label for="">Telefone: </label></td>
                    <td><input required placeholder="Telefone" type="number"></td>
                </tr>

                <tr>
                    <td><label for="">Email: </label></td>
                    <td><input required placeholder="Email" type="text"></td>
                </tr>


                <tr>
                    <td style="text-align: center;" colspan="2">
                        <a href=""><button class="c" name="Confirmar" onclick="msgAlerta(event)" type="button">Confirmar</button></a>
                    </td>
                </tr>


                <tr>
                    <td style="text-align: center;" colspan="2">
                        <a href="pesquisa.php"><button class="c" name="Voltar" type="button">Voltar</button></a>
                    </td>
                </tr>
            </table>
    </form>

    </div>


</body>

</html>


<?php
    extract($_POST);
    if (isset($_POST["Confirmar"])) {
    
        include_once("classes/Connect.php");
        $obj = new conect();
        $resultado = $obj->ConectarBanco();
        
        $sql = "SELECT * FROM contatos";
    

    $executado = $resultado->prepare($sql);
    $indice = 0;
    

    if($executado->execute())
        {
            while($linha = $executado->fetch(PDO::FETCH_ASSOC))
            {
                $linhas[$indice] = $linha;
                $indice++;
            }

            $i = 0;
           
            echo '
            <table class="tabela">
                    <tr>
                        <td>Nome</td>
                        <td>Endereco</td>
                        <td>Email</td>
                        <td>Telefone</td>
                    </tr>';
            while($i < $indice)
            {
                if($i%2 != 0)
                {
                    $cor = "#FFFFFF;";
                }else{
                    $cor = "#CCCCCC;";
                }
            echo '
                
                    <tr style="background-color:'.$cor.'">
                        <td>'.$linhas[$i]['nome'].'</td>
                        <td>'.$linhas[$i]['endereco'].'</td>
                        <td>'.$linhas[$i]['email'].'</td>
                        <td>'.$linhas[$i]['telefone'].'</td>
                    </tr>
            ';
            $i++;
            }
            echo '</table>';
        }
        else
        {
            echo "Deu errado cara!!";
        }
    
    }


?>