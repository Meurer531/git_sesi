<?php
session_start();
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Cadastro</title>
    <link rel="stylesheet" href="adiciona.css">
    <link rel="icon" type="image" href="css/img/rt.png">
</head>

<body>

    <form action="adicionar.php" method="post">

        <h1 class="titu">Adicionar Contatos</h1>

        <div class="central">

            <table>
                <tr>
                    <td colspan="2">&nbsp;</td>
                </tr>

                <tr>
                    <td style="text-align: center;" colspan="2">
                        <img src="img/cont.png" alt="" width="20%">
                    </td>
                </tr>

                <tr>
                    <td><input name="foto" type="file"></td>
                </tr>

                <tr>
                    <td><label for="">Nome: </label></td>
                    <td><input required placeholder="Nome" name="nome" type="text"></td>
                </tr>

                <tr>
                    <td><label for="">Endereço: </label></td>
                    <td><input required placeholder="Endereço" name="endereco" type="text"></td>
                </tr>

                <tr>
                    <td><label for="">Telefone: </label></td>
                    <td><input required placeholder="Telefone" name="telefone" type="number"></td>
                </tr>

                <tr>
                    <td><label for="">Email: </label></td>
                    <td><input required placeholder="Email" name="email" type="text"></td>
                </tr>

                <tr>
                    <td style="text-align: center;" colspan="2">
                        <button class="c" name="Confirmar" type="submit">Confirmar</button>
                    </td>
                </tr>

                <tr>
                    <td style="text-align: center;" colspan="2">
                        <a href="pesquisa.php"><button class="c" name="Voltar" type="button">Voltar</button></a>
                    </td>
                </tr>
            </table>

    </form>

</body>

</html>

<?php

if (isset($_POST["Confirmar"])) {
    include_once("classes/Connect.php");


    $obj = new conect();
    $resultado = $obj->ConectarBanco();

    // Cria a consulta SQL para inserir os dados do contato
    $sql = "INSERT INTO contatos (nome, endereco, telefone, email, usuario_idfk) 
            VALUES (:nome, :endereco, :telefone, :email, :usuario_idfk)";

    // Prepara a consulta SQL
    $executado = $resultado->prepare($sql);

    // Faz o bind dos parâmetros para evitar SQL injection
    $executado->bindParam(':nome', $_POST['nome']);
    $executado->bindParam(':endereco', $_POST['endereco']);
    $executado->bindParam(':telefone', $_POST['telefone']);
    $executado->bindParam(':email', $_POST['email']);
    $executado->bindParam(':usuario_idfk', $_SESSION['id'], PDO::PARAM_INT);


    if ($executado->execute()) {
        // Se a execução for bem-sucedida, redireciona para a página de pesquisa
        header("Location: pesquisa.php");
        exit;
    } else {

        echo "Algo deu errado ao adicionar o contato.";
    }
}




?>