<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
 
<body>


    <form method="post" action="pesquisa.php">

        <form action="">
            <h1 style="color: white;">Editar Contato</h1>
        </form>

    </form>


</body>

</html>