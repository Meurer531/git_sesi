<?php



?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Cadastro</title>
    <link rel="stylesheet" href="css/cadastro1.css">
    <link rel="icon" type="image" href="css/img/rt.png">

    <script>
        function msgAlerta() {

            var input = document.querySelectorAll('input[required]');
            var allFilled = true;

            input.forEach(function(input) {
                if (input.value.trim() === "") {
                    allFilled = false;
                }
            });

            if (allFilled) {
                alert("Cadastro concluído com sucesso.");
            } else {
                alert("Por Favor, preencha todos os campos.");
            }

        }
    </script>

</head>

<body>

    <form action="cadastrar.php" method="post">


        <h1 class="titu">Cadastro de Usuário</h1>

        <div class="central">


            <table>
                <tr>
                    <td coslpan="2">&nbsp;</td>
                </tr>

                <tr>
                    <td style="text-align: center;" colspan="2">
                        <img src="css/img/rt.png" alt="" width="20%">
                    </td>
                </tr>

                <tr>
                    <td><label for="">Nome: </label></td>
                    <td><input required placeholder="Nome" type="text"></td>
                </tr>

                <tr>
                    <td><label for="">Senha: </label></td>
                    <td><input required placeholder="Senha" type="text"></td>
                </tr>

                <tr>
                    <td><label for="">Endereço: </label></td>
                    <td><input required placeholder="Endereço" type="text"></td>
                </tr>

                <tr>
                    <td><label for="">Email: </label></td>
                    <td><input required placeholder="Email" type="text"></td>
                </tr>

                <tr>
                    <td><label for="">Cidade: </label></td>
                    <td><input required placeholder="Cidade" type="text"></td>
                </tr>

                <tr>
                    <td><label for="">Telefone: </label></td>
                    <td><input required placeholder="Telefone" type="number"></td>
                </tr>

                <tr>
                    <td><label for="">Nome Login: </label></td>
                    <td><input required placeholder="Nome Login" type="text"></td>
                </tr>

                <tr>
                    <td style="text-align: center;" colspan="2">
                        <a href=""><button class="c" name="Confirmar" onclick="msgAlerta()" type="button">Confirmar</button></a>
                    </td>
                </tr>


                <tr>
                    <td style="text-align: center;" colspan="2">
                        <a href="index.php"><button class="c" name="Voltar" type="button">Voltar</button></a>
                    </td>
                </tr>
            </table>
    </form>

    </div>


</body>

</html>