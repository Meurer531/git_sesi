<!DOCTYPE html>
<html lang="pt-br">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="css/agenda.css">
    <link rel="icon" type="image" href="css/img/rt.png">
    <title>Login</title>
</head>

<script>
    function msgCampos(event) {
        event.preventDefault();
        const login = document.querySelector('input[name="login"]').value;
        const senha = document.querySelector('input[type="password"]').value;

        if (!login && !senha) {
            alert("Preencha todos os campos.");
        } else if (!login || !senha) {
            alert("Preencha todos os campos.");
        }
    }
</script>

<body>

    <form method="post" action="index.php">
        <div class="central">
            <table>
                <tr>
                    <td colspan="2">&nbsp;</td>
                </tr>
                <tr>
                    <td style="text-align: center;" colspan="2">
                        <img src="css/img/rt.png" alt="" width="20%">
                    </td>
                </tr>
                <tr class="login">
                    <td><label for="">Login:</label></td>
                    <td><input name="login" class="iimg" maxlength="15" type="text"></td>

                </tr>

                <tr class="login">
                    <td><label for="">Senha:</label></td>
                    <td><input class="iimgg" name="password" type="password"></td>
                </tr>

                <tr>
                    <td style="text-align: center; margin-top: 30px" colspan="2">
                        <a href=""><button class="b" name="Confirmar" value="Confirmar" type="submit">Confirmar</button></a>
                    </td>
                </tr>

                <tr>
                    <td style="text-align: center;" colspan="2">
                        <a href="cadastrar.php"><button class="b" name="Cadastrar" type="button">Cadastrar</button></a>
                    </td>




                </tr>
                <tr>
                    <td colspan="2">&nbsp;</td>
                </tr>
            </table>
            <div style="clear:both;">&nbsp;</div>
        </div>
    </form>


</body>

</html>


<?php

extract($_POST);
if (isset($_POST["Confirmar"])) {

    include_once("sys/classes/Connect.php");
    $obj = new conect();
    $resultado = $obj->ConectarBanco();


    $usuacripto = md5($_POST["login"]);
    $passcripto = md5($_POST["password"]);


    $sql = "SELECT login, senha, id_usuario FROM usuario WHERE login ='".$usuacripto."' AND senha = '".$passcripto."';";


    $query = $resultado->prepare($sql);
    $indice = 0;





    if ($query->execute()) {
        while ($linha = $query->fetch(PDO::FETCH_ASSOC)) {
            $linhas[$indice] = $linha;
            $indice++;
        }


        if ($indice == 1) {

            $_SESSION["Login"] = TRUE;
            $_SESSION["id"] = $linhas[0]["id_usuario"];
            $_SESSION["NomeUsua"] = $linhas[0]["NomeUsua"];
            header("location: sys/pesquisa.php");
        } else {
            echo '
            <script>
            alert("Usuário e senha não existe");
            </script>';
        }
    }
}
unset($_POST["Entrar"]);

?>