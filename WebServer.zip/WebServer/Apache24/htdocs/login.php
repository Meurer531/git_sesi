<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="cadastro.css">
    <title>Pagina Login</title>
</head>
<body>
    

    

    <div class="container">

    <div><h1>Cadastro</h1></div>

        <form method="post" action="login.php">
            <table>

                <div class="tr1">
                    <tr>
                        <td><label>Login</label></td>
                        <td><input type="text" name="lg"></td>
                    </tr>
                </div>

                <div class="tr2">
                    <tr>
                        <td><label>Senha</label></td>
                        <td><input type="password" name="senha"></td>
                    </tr>
                </div>

                <div class="tr3">
                    <tr>
                        <td><label>Email</label></td>
                        <td><input type="email" name="email"></td>
                    </tr>
                </div>

                <div>
                    <tr>
                        <td><button type="submit" name="Entrar">Entrar</button></td>
                        <td align="right" colspan="2"></td>
                    </tr>
                </div>

            </table>
        </form>
    </div>

</body>
</html>
<?php
    extract($_POST);
    //isset é para verificar se te algo dentro
    #rapaz, novo metodo de comentar
    if(isset($_POST["Entrar"])){
        include_once("conect.php");
        $obj = new conect();
        $resultado = $obj->ConectarBanco();

        $usuariocriptografado = md5($_POST["lg"]);
        $senhacriptografada = md5($_POST["senha"]);


        $sql = "INSERT INTO Users (usuario, passwod, email) VALUES ('".$usuariocriptografado."', '".$senhacriptografada."','".$_POST["email"]."');";
                #SELECT nome, senha(campos da tabela)
                #FROM usuario(nome da tabela)
                #WHERE nome='".$_POST["usuer"]."'(selecionar o nome escrito no input nome)
                # AND senha = '".$_POST["senha"]."';(selecionar a senha escrito no input senha)
                #lembrando que é um select, só vai mostrar algo no BD se tiver algo

        $query = $resultado->prepare($sql);
        $indice = 0;
        if($query->execute()){
            echo '
            <script>
                alert("Cadastro realizado");
            </script>
            ';
        } 
        else{
            echo '
            <script>
                alert("Cadastro não realizado");
            </script>
            ';
        }    
    }


?>